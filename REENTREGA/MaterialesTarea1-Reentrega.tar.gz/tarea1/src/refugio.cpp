#include "../include/refugio.h"

struct rep_refugio {
    /************ Parte 5.1 ************/
    /*Escriba el código a continuación */

    /****** Fin de parte Parte 5.1 *****/
};

TRefugio crearTRefugio() {
    return NULL; 
}

void liberarTRefugio(TRefugio& refugio) {

}

void agregarEnTRefugio(TRefugio& refugio, TPerro perro) {

}

void imprimirTRefugio(TRefugio refugio) {

}

bool estaEnTRefugio(TRefugio refugio, int id) {
    return false;
}

TPerro obtenerDeTRefugio(TRefugio refugio, int id) {
    return NULL;
}

bool ingresaronPerrosFechaTRefugio(TRefugio refugio, TFecha fecha) {
    return false;
}

void imprimirPerrosFechaTRefugio(TRefugio refugio, TFecha fecha) {

}

void removerDeTRefugio(TRefugio& refugio, int id) {
    
}





