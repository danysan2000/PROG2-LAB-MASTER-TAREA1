#include "../include/perro.h"

struct rep_perro {
    /************ Parte 4.1 ************/
    /*Escriba el código a continuación */

    /****** Fin de parte Parte 4.1 *****/
};

TPerro crearTPerro(int id, const char nombre[MAX_NOMBRE], nat edad, nat vitalidad, const char descripcion[MAX_DESCRIPCION], TFecha fechaIngreso) {
    return NULL; 
}

void liberarTPerro(TPerro &perro) {

}

int idTPerro(TPerro perro) {
    return 0; 
}

char* nombreTPerro(TPerro perro) {
    return NULL; 
}

nat edadTPerro(TPerro perro) {
    return 0;
}

nat vitalidadTPerro(TPerro perro) {
    return 0; 
}

char* descripcionTPerro(TPerro perro) {
    return NULL; 
}

TFecha fechaIngresoTPerro(TPerro perro) {
    return NULL; 
}

void imprimirTPerro(TPerro perro) {

}

TPerro copiarTPerro(TPerro perro) {
    return NULL;
}

void actualizarEdadTPerro(TPerro &perro, nat nuevaEdad) {

}

void actualizarVitalidadTPerro(TPerro &perro, nat nuevaVitalidad) {

}
